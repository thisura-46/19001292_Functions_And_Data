object negRat extends App{
  val n = new Rational(3, 7)
  println(n.neg)
}

class Rational (n:Int, d:Int){
  def numerator = n
  def denomenator = d

  def neg = new Rational(-this.numerator, this.denomenator)
  override def toString = s"$numerator/$denomenator"
}
