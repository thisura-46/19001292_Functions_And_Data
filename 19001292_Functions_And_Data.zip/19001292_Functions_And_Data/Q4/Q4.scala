object Bank extends App {
  val account1 = new Account("982962960V", 1020, 15000.00)
  val account2 = new Account("981458120V", 4578, 20000.00)
  val account3 = new Account("985698247V", 4596, -5000.00)
  val account4 = new Account("987121312V", 9874, -10000.00)
  val account5 = new Account("984567125V", 6823, 25000.00)

  var bank:List[Account] = List(account1, account2, account3, account4, account5)
  val od = (b:List[Account]) => b.filter(x=>x.Balance.<(0.0))
  val sumBalance = (b:List[Account]) => b.reduce((a, b) => new Account("Total", 0, a.Balance+ b.Balance))
  val interest = (b:List[Account]) => b.map(x=> if (x.Balance<0) new Account(x.NIC, x.accountNum, x.Balance*0.1+x.Balance) else new Account(x.NIC, x.accountNum, x.Balance*0.05+x.Balance))
  println("List of Accounts with negative balances: ")
  od(bank).foreach{
    x => print(x.accountNum)
    println()
  }
  println()
  println()
  println(s"Sum of all account balances is: "+sumBalance(bank).Balance)
  println()
  println("Final balances of all accounts after interest: ")
  interest(bank).foreach{
    x => print(x.accountNum)
    print(" = ")
    print(x.Balance)
    println()
  }
}

class Account(id:String, n:Int, b:Double){
  val NIC:String = id
  val accountNum: Int = n
  var Balance: Double = b

  override  def toString = s"[$NIC:$accountNum:$Balance]"
}
