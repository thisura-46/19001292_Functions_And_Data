object Acc extends App {
  val account1 = new Account("982962960V", 1020, 10000.00)
  val account2 = new Account("990220548V", 4587, 15000.00)
  account2.transfer(account1, 4500.00)
  println(account1)
  println(account2)
}

class Account(id:String, n:Int, b:Double){
  val NIC:String = id
  val accountNum: Int = n
  var Balance: Double = b

  def transfer(a:Account, b:Double) = {
    this.Balance -= b
    a.Balance += b
  }
  override  def toString = s"[$NIC:$accountNum:$Balance]"
}
